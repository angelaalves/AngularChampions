import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guild-list-start',
  templateUrl: './guild-list-start.component.html',
  styleUrls: ['./guild-list-start.component.css']
})
export class GuildListStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}